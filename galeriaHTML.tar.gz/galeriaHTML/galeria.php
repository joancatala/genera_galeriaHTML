<p><h1>Primer apartat</h1>

<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-0.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-0.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-1.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-1.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-2.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-2.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-3.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-3.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-4.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-4.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-5.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-5.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-6.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-6.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-7.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-7.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-8.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-8.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/1 Primer-apartat/zamenhof-esperanto-9.jpg"><img class="imatge" src="fotos/1 Primer-apartat/zamenhof-esperanto-9.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
</p><br /><br />

<p><h1>Segon apartat de la galeria</h1>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-0.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-0.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-1.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-1.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-2.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-2.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-3.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-3.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-4.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-4.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-5.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-5.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-6.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-6.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-7.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-7.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-8.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-8.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-9.jpg"><img class="imatge" src="fotos/2 Segon-apartat-de-la-galeria/zamenhof-esperanto-9.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
</p><br /><br />

<p><h1>Mes fotos de Zamenhof</h1>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-0.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-0.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-1.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-1.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-2.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-2.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-3.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-3.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-4.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-4.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-5.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-5.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-6.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-6.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-7.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-7.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-8.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-8.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-9.jpg"><img class="imatge" src="fotos/3 Mes-fotos-de-Zamenhof/zamenhof-esperanto-9.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
</p><br /><br />

<p><h1>L'Esperanto es la meua llengua</h1>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-0.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-0.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-1.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-1.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-2.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-2.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-3.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-3.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-4.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-4.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-5.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-5.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-6.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-6.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-7.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-7.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-8.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-8.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
<a class="fresco" href="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-9.jpg"><img class="imatge" src="fotos/4 L'Esperanto-es-la-meua-llengua/zamenhof-esperanto-9.jpg" alt="Observatori astronomic DIY Paiporta" /></a>
</p><br /><br />

